alert(calculateDaysSinceEpoch(prompt("Introduce la fecha a calcular \n" +
    "en el formato: DDMMMYYYY", "ddmmmyyyy")));